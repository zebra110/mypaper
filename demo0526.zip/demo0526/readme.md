##### fabric-java-sdk使用说明

1、首先需要在操作系统的host文件里，配置fabric网络域名和ip的映射，
如下:192.168.x.x peer0.org1.example.com peer1.org1.example.com  ……
2、将网络中的证书拷贝到本地，以使用的时候读取证书，将代码中证书的目录进行修改。

hyperledger fabric 完整视频教程地址如下:


